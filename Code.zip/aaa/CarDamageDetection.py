import streamlit as st
from detectron2.config import get_cfg
from detectron2.engine import DefaultPredictor
from detectron2 import model_zoo
from PIL import Image
import numpy as np
import cv2
from matplotlib import pyplot as plt
from detectron2.utils.visualizer import Visualizer, ColorMode
from detectron2.data import MetadataCatalog

from util import set_background
import cocoInst

set_background('/Users/het/PycharmProjects/pythodeneme/333.jpeg')

# set title
st.title('Car Damage Detection')

# set header
st.header('Please upload an image')

# upload file
file = st.file_uploader('', type=['png', 'jpg', 'jpeg'])

# load model

predictor = cocoInst.setup_environment()

# load image
if file:
    image = Image.open(file)#.convert('RGB')

    image_array = np.asarray(image)

    # Make a prediction using the model
    outputs = predictor(image_array)
    instances = outputs["instances"].to("cpu")

    # Define your threshold
    threshold = 0.45

    # Filter out low-confidence predictions
    indices = [i for i, score in enumerate(instances.scores) if score > threshold]
    filtered_instances = instances[indices]


    # Visualize the prediction
    visualizer = Visualizer(
        image_array[:, :, ::-1],
        metadata=cocoInst.metadata_catalog(),
        scale=0.8
    )
    out = visualizer.draw_instance_predictions(instances)

    # Sınıflarınız
    classes = ['car','airbag','astar','cam_catlagi','cizik','far_hasar','gocuk','kaput_hasar','kirik-kayip']

    # Her bir sınıfa bir fiyat atayalım
    prices = [100, 8500, 800, 1000, 1200, 27000, 1350, 40000, 13750]  # Örnek fiyatlar

    # Sınıf isimlerini ve fiyatları bir sözlükte birleştirelim
    class_price_dict = dict(zip(classes, prices))

    # Modelinizin çıktısı
    labels = filtered_instances.pred_classes.numpy()

    # Modelinizin çıktısını sınıf isimlerine dönüştürme
    class_names = []
    for i in labels:

            class_names.append(classes[i])


   # st.write("Predicted Class Names:", class_names)
    # Tahmin edilen her bir sınıfın fiyatını ayrı ayrı yazdırma
    for class_name in class_names:
        st.markdown(
            f"<div style='background-color: black; color: white;padding: 16px;'>Class: {class_name}, Price: {class_price_dict[class_name]}</div>",
            unsafe_allow_html=True)

    # Tahmin edilen sınıfların toplam fiyatını hesaplama
    total_price = sum(class_price_dict.get(class_name, 0) for class_name in class_names)

    st.markdown(f"<div style='background-color: black;margin-bottom: 16px; padding: 16px;  color: white;'>Total Price: {total_price}</div>",
                unsafe_allow_html=True)

    # Convert the raw image to a PIL image and convert color from BGR to RGB
    raw_img = Image.fromarray(cv2.cvtColor(image_array, cv2.COLOR_BGR2RGB))

    # Convert the predicted image to a PIL image and convert color from BGR to RGB
    predicted_img = Image.fromarray(cv2.cvtColor(out.get_image()[:, :, ::-1], cv2.COLOR_BGR2RGB))

    # Plot the raw and predicted images side by side
    fig, ax = plt.subplots(1, 2, figsize=(12, 6))
    ax[0].imshow(raw_img)
    ax[0].axis('off')
    ax[0].set_title('Raw Image')
    ax[1].imshow(predicted_img)
    ax[1].axis('off')
    ax[1].set_title('Predicted Image')

    st.pyplot(fig)
