import os
from detectron2.data import MetadataCatalog, DatasetCatalog
from detectron2.data.datasets import register_coco_instances
from detectron2.engine import DefaultPredictor
from detectron2.model_zoo import model_zoo
from detectron2.config import get_cfg

DATA_SET_NAME = 'Bilgi University Car Damage'
ANNOTATIONS_FILE_NAME = "_annotations.coco.json"
dataset_location = '/Users/het/PycharmProjects/finalProject/Bilgi-University-Car-Damage-1'

TRAIN_DATA_SET_NAME = f"{DATA_SET_NAME}-train"
TRAIN_DATA_SET_IMAGES_DIR_PATH = os.path.join(dataset_location, "train")
TRAIN_DATA_SET_ANN_FILE_PATH = os.path.join(dataset_location, "train", ANNOTATIONS_FILE_NAME)

ARCHITECTURE = "mask_rcnn_X_101_32x8d_FPN_3x"  # mask_rcnn_X_101_32x8d_FPN_3x
CONFIG_FILE_PATH = f"COCO-InstanceSegmentation/{ARCHITECTURE}.yaml"
MAX_ITER = 4500
EVAL_PERIOD = 350
BASE_LR = 0.0001
NUM_CLASSES = 9

def register_dataset_once():
    if TRAIN_DATA_SET_NAME not in DatasetCatalog.list():
        register_coco_instances(
            name=TRAIN_DATA_SET_NAME,
            metadata={},
            json_file=TRAIN_DATA_SET_ANN_FILE_PATH,
            image_root=TRAIN_DATA_SET_IMAGES_DIR_PATH
        )

def setup_environment():
    cfg = get_cfg()
    cfg.MODEL.DEVICE = "cpu"
    cfg.merge_from_file(model_zoo.get_config_file(CONFIG_FILE_PATH))
    cfg.DATASETS.TRAIN = (TRAIN_DATA_SET_NAME,)
    cfg.MODEL.ROI_HEADS.NUM_CLASSES = NUM_CLASSES

    cfg.MODEL.WEIGHTS = "model_final.pth"
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.4
    predictor = DefaultPredictor(cfg)
    return predictor

def metadata_catalog():
    return MetadataCatalog.get(TRAIN_DATA_SET_NAME)

# Register the dataset only once
register_dataset_once()

metadata = metadata_catalog()
dataset_train = DatasetCatalog.get(TRAIN_DATA_SET_NAME)
predictor = setup_environment()